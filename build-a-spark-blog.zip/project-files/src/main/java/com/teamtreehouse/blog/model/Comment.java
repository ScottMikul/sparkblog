package com.teamtreehouse.blog.model;

public class Comment {
}
