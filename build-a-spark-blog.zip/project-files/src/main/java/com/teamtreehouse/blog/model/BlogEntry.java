package com.teamtreehouse.blog.model;

public class BlogEntry {
    public boolean addComment(Comment comment) {
        // Store these comments!
        return false;
    }
}
